package org.opentrainer.stepDefinition;

import com.codeborne.selenide.SelenideElement;
import cucumber.api.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.opentrainer.stepDefinition.Pages.*;

import static com.codeborne.selenide.Selenide.$;

public class Asserts {

    @And("^assert that login popup response is \"(.*)\"$")
    public void assertResponseIs(String y) {
        String x = loginPopup.loginPopupIncorrectCredentials().getText();
        Assert.assertEquals(y,x);
        System.out.println("\nThe alert message was: " + x);
    }

    @And("^assert that mainpage register email validation response is: \"(.*)\"$")
    public void assertRegisteredEmailValidationIsCorrect(String y) {
        String x = mainPage.emailError().getText();
        Assert.assertEquals(y,x);
        System.out.println("\nThe alert message was: " + x);
    }

    @And("^assert that mainpage register phone validation response is: \"(.*)\"$")
    public void assertRegisteredPhoneValidationIsCorrect(String y) {
        String x = mainPage.phoneError().getText();
        Assert.assertEquals(y,x);
        System.out.println("\nThe alert message was: " + x);
    }

    @And("^assert that mainpage register password validation response contains: \"(.*)\"$")
    public void assertRegisteredPasswordValidationIsCorrect(String y) {
        String x = mainPage.passwordError().getText();
        if(x.contains(y)) {
            System.out.println("\nThe alert message was: " + x);
        } else {
            throw new AssertionError();
        }
    }

    @And("^assert that mainpage register captcha validation response is: \"(.*)\"$")
    public void assertRegisteredCaptchaValidationIsCorrect(String y) {
        String x = mainPage.captchaError().getText();
        Assert.assertEquals(y,x);
        System.out.println("\nThe alert message was: " + x);
    }

    @And("^assert that mainpage register name validation response is: \"(.*)\"$")
    public void assertRegisteredNameValidationIsCorrect(String y) {
        String x = mainPage.nameError().getText();
        Assert.assertEquals(y,x);
        System.out.println("\nThe alert message was: " + x);
    }

    @And("^assert that open-broker.ru opened on the page open-account$")
    public void assertOpenBrokerOpensOnOpenAccountPage() {
        String x = mainPage.openBrokerAccountTitle().getText();
        String y = "Не посещая офис, онлайн";
        SelenideElement z = $(By.cssSelector("#new-header > div > div > div.headers > div > div.header.header--type-static.header--theme-light > div.header__content.header__content-common > a > img"));
        if(x.contains(y) && z.exists()) {
            System.out.println("\nThe alert message was: " + x);
        } else {
            throw new AssertionError("The actual response: " + x + " expected: " + y);
        }
    }

    @And("^assert that Pdf links are present on register popup$")
    public void assertPdfLinksRegisterPopup() {
        Assert.assertTrue(registerPopup.communicationPdf().exists());
        Assert.assertTrue(registerPopup.personalDataPdf().exists());
    }

    @And("^assert that social networks login links are present on register popup$")
    public void assertSocialNetworksLinksRegisterPopup() {
        Assert.assertTrue(registerPopup.facebookLink().exists());
        Assert.assertTrue(registerPopup.vkontakteLink().exists());
    }

    @And("^assert that element \"(.*)\" is missing$")
    public void assertThatElementIsMissing(SelenideElement element) {
        Assert.assertTrue(!element.exists());
    }

    @And("^assert that element add event to calendar is missing$")
    public void assertThatAddToCalendarIsMissing() {
        Assert.assertTrue(!webinars.addRemiderToCalendar().exists());
    }

    @And("^assert that registration to join the webinar is required$")
    public void assertThatRegistrationToJoinWebinarRequired() {
        Assert.assertTrue(webinars.registerToJoinTheWebinar().exists());
    }

    @And("Assert that registration popup opens")
    public void assertRegistrationPopupOpens() {
        Assert.assertTrue(mainPage.registrationPopup().exists());
    }

    @And("Assert that test failed and button Try Again appears")
    public void assertTestFailButtonTryAgain() {
        Assert.assertTrue(finalTest.buttonTryAgain().exists() && finalTest.fifteenthWrongAnswer().exists());
    }

//    @And("^assert that the response is not \"(.*)\"$")
//    public void assertResponseIsNot(String y) throws SQLException {
//        while(r.resultSet.next()) {
//            r.x = r.resultSet.getString(1);
//        }
//        Assert.assertNotEquals(y,x);
//        System.out.println("The response is: " + r.x);
//    }
}
