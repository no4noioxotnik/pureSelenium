package org.opentrainer.stepDefinition.Pages;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;

public class passwordRecoveryPopup {

    public static SelenideElement passwordRecoveryPopupEmail() {
        return $(By.xpath("//*[@id='new_password_user_form']/div[1]/*[@id='user_email']"));
    }

    public static SelenideElement passwordRecoveryPopupSubmit() {
        return $(By.xpath("//*[@id='new_password_user_form']/div[2]/*[@id='gif_btn']"));
    }
}
