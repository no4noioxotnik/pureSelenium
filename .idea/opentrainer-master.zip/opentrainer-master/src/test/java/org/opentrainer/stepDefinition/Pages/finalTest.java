package org.opentrainer.stepDefinition.Pages;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;

public class finalTest {
    public static SelenideElement firstCorrectAnswer() {
        return $(By.cssSelector("#lbl_answer530"));
    }

    public static SelenideElement secondCorrectAnswer() {
        return $(By.cssSelector("#lbl_answer1768"));
    }

    public static SelenideElement thirdCorrectAnswer() {
        return $(By.cssSelector("#lbl_answer536"));
    }

    public static SelenideElement fourthCorrectAnswer() {
        return $(By.cssSelector("#lbl_answer538"));
    }

    public static SelenideElement fithCorrectAnswer() {
        return $(By.cssSelector("#lbl_answer544"));
    }

    public static SelenideElement sixthCorrectAnswer() {
        return $(By.cssSelector("#lbl_answer547"));
    }

    public static SelenideElement seventhCorrectAnswer() {
        return $(By.cssSelector("#lbl_answer551"));
    }

    public static SelenideElement eighthCorrectAnswer() {
        return $(By.cssSelector("#lbl_answer552"));
    }

    public static SelenideElement ninthCorrectAnswer() {
        return $(By.cssSelector("#lbl_answer555"));
    }

    public static SelenideElement tenthCorrectAnswer() {
        return $(By.cssSelector("#lbl_answer559"));
    }

    public static SelenideElement eleventhCorrectAnswer() {
        return $(By.cssSelector("#lbl_answer563"));
    }

    public static SelenideElement twelthCorrectAnswer() {
        return $(By.cssSelector("#lbl_answer568"));
    }

    public static SelenideElement twelthIncorrectAnswer() {
        return $(By.cssSelector("#lbl_answer567"));
    }

    public static SelenideElement thirteenthCorrectAnswer() {
        return $(By.cssSelector("#lbl_answer572"));
    }

    public static SelenideElement thirteenthIncorrectAnswer() {
        return $(By.cssSelector("#lbl_answer570"));
    }

    public static SelenideElement fourteenthCorrectAnswer() {
        return $(By.cssSelector("#lbl_answer576"));
    }

    public static SelenideElement fourteenthIncorrectAnswer() {
        return $(By.cssSelector("#lbl_answer575"));
    }

    public static SelenideElement fifteenthCorrectAnswer() {
        return $(By.cssSelector("#lbl_answer578"));
    }

    public static SelenideElement fifteenthIncorrectAnswer() {
        return $(By.cssSelector("#lbl_answer579"));
    }

    public static SelenideElement submitAnswers() {
        return $(By.cssSelector("#submit_answers"));
    }

    public static  SelenideElement buttonTryAgain() {
        return $(By.xpath("//div[@id='submit_button_div']/a[2]"));
    }

    public static  SelenideElement fifteenthWrongAnswer() {
        return $(By.xpath("//*[@id='lbl_answer579'][contains(@class,'wrong-answer')]"));
    }

}
