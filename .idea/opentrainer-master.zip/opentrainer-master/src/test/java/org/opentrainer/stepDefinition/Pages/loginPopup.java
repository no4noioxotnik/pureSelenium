package org.opentrainer.stepDefinition.Pages;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;

public class loginPopup {

    public static SelenideElement loginPopupEmail() {
        return $(By.xpath("//*[@id='new_user_session_form']/div[1]/*[@id='user_email']"));
    }

    public static SelenideElement loginPopupPassword() {
        return $(By.xpath("//*[@id='new_user_session_form']/div[2]/*[@id='user_password']"));
    }

    public static SelenideElement loginPopupSubmit() {
        return $(By.xpath("//*[@id='new_user_session_form']/div[3]/input"));
    }

    public static SelenideElement loginPopupForgotPassword() {
        return $(By.xpath("//*[@id='new_user_session_form']/*[@id = 'user_redirect_to_pass_rec']"));
    }

    public static SelenideElement loginPopupIncorrectCredentials() {
        return $(By.xpath("//*[@id='new_user_session_form']/div[1]/label[@class='error-input']"));
    }

}
