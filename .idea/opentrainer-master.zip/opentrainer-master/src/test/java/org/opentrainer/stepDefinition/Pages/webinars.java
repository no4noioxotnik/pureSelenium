package org.opentrainer.stepDefinition.Pages;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;

public class webinars {

    public static SelenideElement freeWebinars() {
        return $(By.cssSelector("#filter-free"));
    }

    public static SelenideElement freeWebinarHowToInvest() {
        return $(By.cssSelector("#webinar_tile_326 > a > div > div.title"));
    }

    public static SelenideElement addRemiderToCalendar() {
        return $(By.xpath("//a[contains(text(), 'Добавить напоминание')]"));
    }

    public static SelenideElement registerToJoinTheWebinar() {
        return $(By.cssSelector("#to-hide-on-result"));
    }
}
