package org.opentrainer.stepDefinition.Pages;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;

public class mainPage {

    public static SelenideElement mainPageLearn() {
        return $(By.xpath("/html/body/div[1]/div/div[2]/div/a[1]"));
    }

    public static SelenideElement mainPageTrain() {
        return $(By.xpath("/html/body/div[1]/div/div[2]/div/a[2]"));
    }

    public static SelenideElement mainPageRead() {
        return $(By.xpath("/html/body/div[1]/div/div[2]/div/a[3]"));
    }

    public static SelenideElement mainPageRegisterEmail() {
        return $(By.id("user_email"));
    }

    public static SelenideElement mainPageLogin() {
        return $(By.className("sign-in-a"));
    }

    public static SelenideElement registerName() {
        return $(By.xpath("//*[@id='user_fname']"));
    }

    public static SelenideElement registerSurname() {
        return $(By.xpath("//*[@id='user_lname']"));
    }

    public static SelenideElement registerPhoneCode() {
        return $(By.xpath("//*[@id='user_phone_code_dashboard']"));
    }

    public static SelenideElement registerPhoneNumber() {
        return $(By.xpath("//*[@id='user_phone_number_dashboard']"));
    }

    public static SelenideElement registerCaptcha() {
        return $(By.xpath("//*[@id='new_user']/div[5]//*[@id='user_captcha']"));
    }

    public static SelenideElement registerUserPassword() {
        return $(By.id("user_password"));
    }

    public static SelenideElement registerButton() {
        return $(By.xpath("//*[@id='new_user']/div[6]/*[@id='gif_btn']"));
    }

    public static SelenideElement emailError() {
        return $(By.cssSelector("#new_user > div.placeholder-form.even-child > label"));
    }

    public static SelenideElement phoneError() {
        return $(By.cssSelector("#new_user > div.phone-form > label"));
    }

    public static SelenideElement passwordError() {
        return $(By.cssSelector("#new_user > div.placeholder-form.fix-errors > label"));
    }

    public static SelenideElement captchaError() {
        return $(By.cssSelector("#new_user > div.placeholder-form.captcha > label"));
    }

    public static SelenideElement nameError() {
        return $(By.cssSelector("#error-name-input"));
    }

    public static SelenideElement LogedInFollowStyudyPlan() {
        return $(By.cssSelector("#plan > div.plan-block.active > div > a"));
    }

    public static SelenideElement openAccount() {
        return $(By.cssSelector("#open-an-account-header-menu"));
    }

    public static SelenideElement openBrokerAccountTitle() {
        return $(By.cssSelector("body > div.sitewrap > div.intro-wrap > div > div.intro-content"));
    }

    public static SelenideElement nameHeader() {
        return $(By.cssSelector("#header_menu_holder > div.info-block > a"));
    }

    public static SelenideElement signOut() {
        return $(By.cssSelector("#header_menu > div.menu-item.even-child.last-child > a"));
    }

    public static SelenideElement videoCourses() {
        return $(By.cssSelector("body > div.content-wrapper > div > div.gray-navigate > div > a:nth-child(2)"));
    }

    public static SelenideElement registrationPopup() {
        return $(By.cssSelector("#register_popup > div > div"));
    }

    public static SelenideElement closeRegistrationPopup() {
        return $(By.cssSelector("#register_popup > div > div > img"));
    }
}
