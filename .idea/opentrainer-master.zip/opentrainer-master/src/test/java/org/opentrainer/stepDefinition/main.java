package org.opentrainer.stepDefinition;
import com.codeborne.selenide.SelenideElement;
import cucumber.api.DataTable;
import cucumber.api.java.cs.A;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.opentrainer.stepDefinition.Pages.*;

import java.util.Map;
import java.util.Set;

import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.WebDriverRunner.getWebDriver;


public class main {

    private ChromeDriver driver;
    private String mainpage;

    @Given("^browser: \"(.+)\"$")
    public void setupClass(String browser) {
        switch (browser.toLowerCase()) {
            case "chrome":
                System.setProperty("chromedriver.exe", "/src/test/resources");
                System.setProperty("selenide.browser", browser);
                break;
            case "firefox":
//                System.setProperty("chromedriver.exe", "/src/test/resources");
//                System.setProperty("selenide.browser", browser);
                break;
        }
    }

    @When("^open page: \"(.*)\"$")
    public void openPage(String page) {
        open(page);
        Set<String> handles = getWebDriver().getWindowHandles();
        System.out.println("Main window value: " + handles);
        this.mainpage = page;
    }

    @And("^confirm location if needed$")
    public void confirmLocationIfNeeded() {
        if ($(By.id("tost_for_office")).exists()) {
            $(By.id("office_yes")).click();
        }
    }

    @And("^wait: \"(\\d+)\" milliseconds$")
    public void wait(int per) throws InterruptedException {
        Thread.sleep(per);
    }

    @Then("^choose to login$")
    public void login() throws InterruptedException {
        mainPage.mainPageLogin().click();
        Thread.sleep(1000);
    }

    @Then("^choose to register$")
    public void register() {
        $(By.xpath("//*[@id='user_header']/div/div[1]/div/a[2]")).click();
    }

    @And("^type email \"(.*)\"$")
    public void typeEmail(String email) {
        loginPopup.loginPopupEmail().sendKeys(email);
    }

    @And("^set password recovery email as: \"(.*)\"$")
    public void setPasswordRecoveryEmailAs(String email) {
        passwordRecoveryPopup.passwordRecoveryPopupEmail().sendKeys(email);
    }

    @And("^submit password recovery$")
    public void submitPasswordRecovery() {
        passwordRecoveryPopup.passwordRecoveryPopupSubmit().click();
    }

    @And("^type password \"(.*)\"$")
    public void typePassword(String password) {
        loginPopup.loginPopupPassword().sendKeys(password);
    }

    @And("^submit login popup$")
    public void submitLoginPopup() throws InterruptedException {
        loginPopup.loginPopupSubmit().click();
        Thread.sleep(4000);
    }

    @And("^on the mainpage choose: \"(.*)\"$")
    public void chooseLearnFromMainPage(String option) {
        switch (option) {
            case "LEARN": mainPage.mainPageLearn().click();
            break;
            case "TRAIN": mainPage.mainPageTrain().click();
            break;
            case "READ": mainPage.mainPageRead().click();
            break;
        }
    }

    @And("^and choose forgot password$")
    public void forgotPasswordLoginPopup() {
        loginPopup.loginPopupForgotPassword().click();
    }

    @And("^close popup$")
    public void closePopup() {
        $(By.xpath("//*[@id='register_popup']/div/div/img")).click();
    }

    @And("^set name as \"(.*)\" and surname as \"(.*)\"$")
    public void setCredentials(String name, String surname) {
        mainPage.registerName().sendKeys(name);
        mainPage.registerSurname().sendKeys(surname);
    }

    @And("^set user phone as: 7 9\"(.*)\" \"(.*)\"-\"(.*)\"-\"(.*)\"$")
    public void phoneNumber(String code, String firstGroup, String secondGroup, String thirdGroup) throws InterruptedException {
        mainPage.registerPhoneCode().sendKeys(code);
        Thread.sleep(2000);
        mainPage.registerPhoneNumber().doubleClick();
        mainPage.registerPhoneNumber().sendKeys(firstGroup + secondGroup + thirdGroup);
        Thread.sleep(2000);
    }

    @And("^set email as: \"(.*)\"$")
    public void setEmailAs(String email) {
        mainPage.mainPageRegisterEmail().sendKeys(email);
    }

    @And("^set user password \"(.*)\"$")
    public void setPassword(String password) {
        mainPage.registerUserPassword().sendKeys(password);
    }

    @And("^set captcha \"(.*)\"$")
    public void setCaptcha(String captcha) {
        if (captcha.equals("timestamp")) {
            mainPage.registerCaptcha().sendKeys(getTs());
        } else {
            mainPage.registerCaptcha().sendKeys(captcha);
        }
    }

    public String getTs() {
    long ts = System.currentTimeMillis() / 1000L;
    return String.valueOf(ts);
    }

    @When("^check if pages opens$")
    public void checkIfPagesOpens(DataTable pages) throws InterruptedException {

        for (Map<String,String> data : pages.asMaps(String.class,String.class)) {
            open(mainpage + (data.get("Page")));
            $(By.xpath("//*[@id='header_logo']")).exists();
        }
    }

    @And("^choose to create broker account from profile$")
    public void createBrokerAccountFromProfile() {
        mainPage.openAccount().click();
    }

    @And("^choose free webinars$")
    public void chooseFreeWebinars() {
        webinars.freeWebinars().click();
    }

    @And("^push register button$")
    public void pushRegisterButton() throws InterruptedException {
        mainPage.registerButton().click();
        Thread.sleep(5000);
    }

    @And("^follow to Watch Study Plan$")
    public void followStudyPlan() {
        mainPage.LogedInFollowStyudyPlan().click();
    }

    @And("^choose \"(.*)\" plan$")
    public void followPlan(String plan) {
        switch (plan) {
            case "Specialist": planCurrentrank.planSpecialist().click();
                break;
        }
    }

    @And("choose \"(.*)\" video")
    public void chooseVideo(String video) {
        switch (video) {
            case "Academy of success trading": planCurrentrank.AccOfSuccessTraiding().click();
        }
    }

    @And("while logged out choose \"(.*)\" video")
    public void loggedOutChooseVideo(String video) {
        switch (video) {
            case "Academy of success trading": planCurrentrank.AccOfSuccessTraidingLogedOut().click();
        }
    }

    @And("^choose text version of seminar$")
    public void chooseTextVersion() throws InterruptedException {
        planCurrentrank.termsTextVersion().click();
        Thread.sleep(1000);
    }

    @And("^choose text version of seminar while logged in$")
    public void chooseTextVersionWhileLogedIn() throws InterruptedException {
        planCurrentrank.loggedInTermsTextVersion().click();
        Thread.sleep(1000);
    }

    @And("^navigate Back$")
    public void navigateBack() {
        navigator.back();
    }

    @And("^watch terms and definitions video$")
    public void watchTesmsVideo() {
        planCurrentrank.watchLession().click();
    }

    @And("^choose free webinar How To Invest$")
    public void chooseFreeWebinarHowToInvest() {
        webinars.freeWebinarHowToInvest().click();
    }

    @And("^watch next video$")
    public void watchNextVideo() {
        planCurrentrank.watchNextLession().click();
    }

    @And("^close lesson video$")
    public void closeLessonVideo() {
        planCurrentrank.closeLession().click();
    }

    @Then("^add reminder to calendar$")
    public void addReminderToCalendar() throws InterruptedException {
        Thread.sleep(1000);
        webinars.addRemiderToCalendar().click();
    }

    @And("^i want to logout$")
    public void logout() {
        mainPage.nameHeader().click();
        mainPage.signOut().click();
    }

    @And("^choose video courses$")
    public void videoCourses() {
        mainPage.videoCourses().click();
    }

    @And("^close registration popup$")
    public void closeRegistrationPopup() {
        mainPage.closeRegistrationPopup().click();
    }

    @And("^choose to watch lesson$")
    public void chooseToWatchLession() throws InterruptedException {
        planCurrentrank.watchTermsAndConditions().click();
        Thread.sleep(1000);
    }

    @And("^i want to pass the final test$")
    public void passFinalTest() throws InterruptedException {
        finalTest.firstCorrectAnswer().click();
        finalTest.secondCorrectAnswer().click();
        finalTest.thirdCorrectAnswer().click();
        finalTest.fourthCorrectAnswer().click();
        finalTest.fithCorrectAnswer().click();
        finalTest.sixthCorrectAnswer().click();
        finalTest.seventhCorrectAnswer().click();
        finalTest.eighthCorrectAnswer().click();
        finalTest.ninthCorrectAnswer().click();
        finalTest.tenthCorrectAnswer().click();
        finalTest.eleventhCorrectAnswer().click();
        finalTest.twelthCorrectAnswer().click();
        finalTest.thirteenthCorrectAnswer().click();
        finalTest.fourteenthCorrectAnswer().click();
        finalTest.fifteenthCorrectAnswer().click();
        finalTest.submitAnswers();
        Thread.sleep(1000);
    }

    @And("^i want to fail the final test$")
    public void failFinalTest() throws InterruptedException {
        finalTest.firstCorrectAnswer().click();
        finalTest.secondCorrectAnswer().click();
        finalTest.thirdCorrectAnswer().click();
        finalTest.fourthCorrectAnswer().click();
        finalTest.fithCorrectAnswer().click();
        finalTest.sixthCorrectAnswer().click();
        finalTest.seventhCorrectAnswer().click();
        finalTest.eighthCorrectAnswer().click();
        finalTest.ninthCorrectAnswer().click();
        finalTest.tenthCorrectAnswer().click();
        finalTest.eleventhCorrectAnswer().click();
        finalTest.twelthIncorrectAnswer().click();
        finalTest.thirteenthIncorrectAnswer().click();
        finalTest.fourteenthIncorrectAnswer().click();
        finalTest.fifteenthIncorrectAnswer().click();
        finalTest.submitAnswers().click();
        Thread.sleep(5000);
    }

    @And("^i want to try the test again$")
    public void tryTheFinalTestAgain() {
        finalTest.buttonTryAgain().click();
    }

}
