package org.opentrainer.stepDefinition.Pages;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;

public class registerPopup {

    public static SelenideElement registerPopupCaptcha() {
        return $(By.xpath("//*[@id='register_popup']//*[@id='new_user_form']//*[@id='new_user']/div[5]//*[@id='user_captcha']"));
    }

    public static SelenideElement registerPopupPhoneCode() {
        return $(By.xpath("//*[@id='user_phone_code']"));
    }

    public static SelenideElement registerPopupPhoneNumber() {
        return $(By.xpath("//*[@id='user_phone_number']"));
    }

    public static SelenideElement personalDataPdf() {
       return  $(By.cssSelector("#new_user > p.register-conditions.to-hide-on-result > a"));
    }

    public static SelenideElement communicationPdf() {
        return  $(By.cssSelector("#new_user > p.light.to-hide-on-result > a"));
    }

    public static SelenideElement facebookLink() {
        return $(By.cssSelector("#social_reg_link_facebook"));
    }

    public static SelenideElement vkontakteLink() {
        return $(By.cssSelector("#social_reg_link_vkontakte"));
    }

}
