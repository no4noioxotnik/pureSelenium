package org.opentrainer.stepDefinition.Pages;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;

public class planCurrentrank {
    public static SelenideElement planSpecialist() {
        return $(By.cssSelector("#page_dashboard > div:nth-child(3) > div > div > div:nth-child(1) > h4"));
    }

    public static SelenideElement AccOfSuccessTraiding() {
        return $(By.cssSelector("#page_dashboard > div:nth-child(4) > div.task.first-child > a"));
    }

    public static SelenideElement AccOfSuccessTraidingLogedOut() {
        return $(By.cssSelector("#redirect_to_course_11 > div.corner-left > p"));
    }

    public static SelenideElement termsTextVersion() {
        return $(By.cssSelector("#lesson_34 > div.course-control > div.menu-item.even-child.last-child"));
    }

    public static SelenideElement loggedInTermsTextVersion() {
        return $(By.cssSelector("#lesson_34 > div.lesson.started > div.course-control > div.menu-item.even-child.last-child"));
    }

    public static SelenideElement watchLession() {
        return $(By.cssSelector("#start_video_34"));
    }

    public static SelenideElement watchNextLession() {
        return $(By.cssSelector("#next_lesson"));
    }

    public static SelenideElement closeLession() {
        return $(By.cssSelector("#lesson_popup > div > div > div.lesson.started.video-lesson > div.menu-block > div.button-holder.close-lesson-popup > a"));
    }

    public static SelenideElement watchTermsAndConditions() {
        return $(By.cssSelector("#lesson_34 > div.course-control > div.menu-item.first-child > a"));
    }
}
